from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import pyqtgraph as pg
import pandas as pd
import sys
import matplotlib
import numpy as np
matplotlib.use('Qt5Agg')

from PyQt5 import QtCore, QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
import seaborn as sns

class MplCanvas(FigureCanvas):
    kind = "scatter"

    def __init__(self, parent):
        self.fig = Figure(figsize=(5, 4), dpi=100)
        super(MplCanvas, self).__init__(self.fig)

    def load(self, dataFrame):
        k = 0
        for column1 in dataFrame.columns:
            if dataFrame[column1].dtypes == "float64" or dataFrame[column1].dtypes == "int64":
                k += 1

        if self.kind == "scatter":
            i = 0
            for column1 in dataFrame.columns:
                for column2 in dataFrame.columns:
                    if (column1 != column2 and (dataFrame[column1].dtypes == "float64" or dataFrame[column1].dtypes == "int64")
                    and (dataFrame[column2].dtypes == "float64" or dataFrame[column2].dtypes == "int64")):
                        axes = self.fig.add_subplot(k, k, i+1)
                        df = dataFrame.loc[:,[column1, column2]]
                        plt = df.plot(x=column1, y=column2, kind="scatter", ax=axes, legend=False)
                        if i % k != 0:
                            plt.set(yticklabels=[])
                            plt.set(ylabel=None)
                            plt.tick_params(bottom=False)
                        if i < k**2 - 2*k:
                            plt.set(xticklabels=[])
                            plt.set(xlabel=None)

                        i += 1
        elif self.kind == "bar":
            axes = self.fig.add_subplot(1,1,1)
            df = dataFrame
            plt = df.plot(kind="bar", ax=axes, legend=False)
        self.draw()
        # self.axis.cla() clears the canvas

class Barchart(FigureCanvas):

    def __init__(self, parent):
        self.fig = Figure(figsize=(5, 4), dpi=100)
        super(MplCanvas, self).__init__(self.fig)

class Heatmap(FigureCanvas):

    def __init__(self, parent):
        self.fig = Figure(figsize=(5, 4), dpi=100)
        super(MplCanvas, self).__init__(self.fig)

class FileReader(QWidget):

    database = None

    def __init__(self, parent, *args, **kwargs):
        super(FileReader, self).__init__(*args, **kwargs)
        self.parent = parent
        self.setAutoFillBackground(True)
        self.setStyleSheet("QWidget"
                        "{"
                        "background : white"
                        "}")
        self.UiComponents()

    def UiComponents(self):
        self.vis1Btn = QPushButton('Visualization 1', self)
        self.vis1Btn.setGeometry(10,10,133,30)
        self.vis1Btn.clicked.connect(lambda: self.changeVis("correlogram"))

        self.vis2Btn = QPushButton('Visualization 2', self)
        self.vis2Btn.setGeometry(133,10,133,30)
        self.vis2Btn.clicked.connect(lambda: self.changeVis("barchart"))

        self.vis3Btn = QPushButton('Visualization 3', self)
        self.vis3Btn.setGeometry(266,10,133,30)
        self.vis3Btn.clicked.connect(lambda: self.changeVis("heatmap"))

        self.openFileBtn = QPushButton('Open file', self)
        self.openFileBtn.setGeometry(10,40,133,30)
        self.openFileBtn.clicked.connect(self.openFile)

        self.loadingLabel = QLabel('Nothing loaded yet', self)
        self.loadingLabel.setGeometry(134,40,133,30)
        self.loadingLabel.setStyleSheet("QWidget"
                        "{"
                        "background : lightblue"
                        "}")

        self.setSelectedBtn = QPushButton('Set selected', self)
        self.setSelectedBtn.setGeometry(267,40,133,30)
        self.setSelectedBtn.clicked.connect(self.on_click)

        self.fileLocation = QTextEdit("set here the directory to the dataset", self)
        self.fileLocation.setLineWrapMode(QTextEdit.WidgetWidth)
        self.fileLocation.setWordWrapMode(QTextOption.WrapAnywhere)
        self.fileLocation.setGeometry(10,70,400,30)

        self.table = QTableWidget(self)
        self.table.setGeometry(10, 100, 400,400)

    def openFile(self):
        self.loadingLabel.setText("Loading")
        self.database = pd.read_csv(self.fileLocation.toPlainText(), sep=";")
        self.table.setRowCount(self.database.shape[0])
        self.table.setColumnCount(self.database.shape[1])
        for x in range(self.database.shape[0]):
            for y in range(self.database.shape[1]):
                column_name = self.database.columns[y]
                self.table.setItem(x,y, QTableWidgetItem(str(self.database.loc[x,column_name])))
        self.table.setHorizontalHeaderLabels(self.database.columns)
        self.loadingLabel.setText("Opened file successfully")
        self.parent.setWidget("correlogram", self.database)

    @pyqtSlot()
    def on_click(self):
        print("\n")
        for currentQTableWidgetItem in self.table.selectedItems():
            print(currentQTableWidgetItem.row(), currentQTableWidgetItem.column(), currentQTableWidgetItem.text())

    def changeVis(self, vis):
        self.parent.setWidget(vis, self.database)

class Window(QMainWindow):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setWindowTitle("Hello")
        self.showFullScreen();
        self.UiComponents()

        self.show()

    def UiComponents(self):
        self.widget = QWidget()
        self.layout = QGridLayout()

        self.leftWidget = QWidget(self.widget)
        self.leftWidget.setGeometry(0,0, 420,1080)
        self.leftWidget.setStyleSheet("QWidget"
                        "{"
                        "background : lightblue"
                        "}")
        self.layout.addWidget(self.leftWidget, 0, 0, 1, 1)

        self.fileWidget = FileReader(self, self.leftWidget)
        self.fileWidget.setGeometry(0,0, 420,540)
        self.outputLayout = QWidget(self.leftWidget)
        self.outputLayout.setGeometry(0,540, 420,540)

        self.mWiget = QWidget(self.widget)
        self.mWiget.setGeometry(420, 0, 1500, 1080)
        self.mlayout = QVBoxLayout()
        self.mainWidget = MplCanvas(self.widget)
        self.mainWidget.setGeometry(420, 0, 1500, 1080)
        self.mlayout.addWidget(self.mainWidget)
        self.mWiget.setLayout(self.mlayout)
        self.layout.addWidget(self.mWiget, 0, 1, 1, 4)


        self.widget.setLayout(self.layout)
        self.setCentralWidget(self.widget)

    def setWidget(self, widget, database):
        self.layout.removeWidget(self.mWiget)
        if widget == "correlogram":
            self.mWiget = QWidget(self.widget)
            self.mWiget.setGeometry(420, 0, 1500, 1080)
            self.mlayout = QVBoxLayout()
            fig = sns.pairplot(database, ).fig
            fig.set_size_inches(2, 2)
            self.mainWidget = FigureCanvas(fig)
            self.mainWidget = MplCanvas(self.widget)
            self.mainWidget.setGeometry(420, 0, 1500, 1080)
            self.mlayout.addWidget(self.mainWidget)
            self.mWiget.setLayout(self.mlayout)
        elif widget == "barchart":
            self.mWiget = QWidget(self.widget)
            self.mWiget.setGeometry(420, 0, 1500, 1080)
            self.mlayout = QVBoxLayout()
            # self.mainWidget = MplCanvas(self.widget)
            self.mainWidget.setGeometry(420, 0, 1500, 1080)
            self.mlayout.addWidget(self.mainWidget)
            self.mWiget.setLayout(self.mlayout)
        elif widget == "heatmap":
            self.mWiget = QWidget(self.widget)
            self.mWiget.setGeometry(420, 0, 1500, 1080)
            self.mlayout = QVBoxLayout()
            # self.mainWidget = MplCanvas(self.widget)
            self.mainWidget.setGeometry(420, 0, 1500, 1080)
            self.mlayout.addWidget(self.mainWidget)
            self.mWiget.setLayout(self.mlayout)
        self.layout.addWidget(self.mWiget, 0, 1, 1, 4)

app = QApplication([])
app.setStyle('Fusion')
window = Window()
window.show()
app.exec_()
